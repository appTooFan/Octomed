
let data_List_chats = [ // قاعده بيانات قائمه عرض الاضافات
  {
    "img": "chat",
    "h1": "المجموعه الرسميه",
    "p": "خاصه بالفعليات والانشطه ودورة طوفان الاقصى",
    "new": true
  },
  {
    "img": "delete_chats",
    "h1": "مستوى اول م الرسميه",
    "p": "مجموعه خاصه بالمنهج مثل اوقات المحاضرات",
    "new": "soon"
  },
  {
    "img": "sendsms",
    "h1": "غرفة دردشه عامه",
    "p": "مجموعه يسمح للجميع برسال الرسائل وتناقش",
    "new": false
  }
  
  
];

footerdiv[2].addEventListener('click', function() {
  if (change_Page.classList.contains('chats')==false) {
    change_Page.innerHTML = "";
    classremove();
document.querySelector('.views').style.display = 'none';
    change_Page.classList.add('chats');
  
    for (let i = 0; i < data_List_chats.length; i++) {
  let containeradds = document.querySelector('.chats');
  let divcontaineradds = document.createElement('div');
  divcontaineradds.classList.add("div_Items");
  containeradds.appendChild(divcontaineradds);
  let imgcontaineradds = document.createElement('img');
  imgcontaineradds.src = `img/adds/chats/${data_List_chats[i].img}.png`
  divcontaineradds.appendChild(imgcontaineradds);
  let h1containeradds = document.createElement('h1');
  h1containeradds.innerHTML = data_List_chats[i].h1
  divcontaineradds.appendChild(h1containeradds);
  let h3_New = document.createElement('h3');
  if (data_List_chats[i].new == true)
  {
    h3_New.innerHTML = `
 <p>5</p>
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<g id="34) icon/bell">
<path id="Mask" fill-rule="evenodd" clip-rule="evenodd" d="M23 17C23 17.6 22.6 18 22 18H2C1.4 18 1 17.6 1 17C1 16.4 1.4 16 2 16C3.1 16 4 15.1 4 14V9C4 4.6 7.6 1 12 1C16.4 1 20 4.6 20 9V14C20 15.1 20.9 16 22 16C22.6 16 23 16.4 23 17ZM14.6 21.5003C14 22.5003 13 23.0003 12 23.0003C11.5 23.0003 11 22.9003 10.5 22.6003C10 22.3003 9.7 22.0003 9.4 21.5003C9.1 21.0003 9.3 20.4003 9.8 20.1003C10.3 19.8003 10.9 20.0003 11.2 20.5003C11.2303 20.5306 11.2606 20.5701 11.2936 20.6131C11.3697 20.7123 11.4606 20.8306 11.6 20.9003C12.1 21.2003 12.7 21.0003 13 20.5003C13.3 20.0003 13.9 19.9003 14.4 20.1003C14.9 20.3003 14.9 21.0003 14.6 21.5003ZM18 14C18 14.7 18.2 15.4 18.5 16H5.5C5.8 15.4 6 14.7 6 14V9C6 5.7 8.7 3 12 3C15.3 3 18 5.7 18 9V14Z" fill="#14142B"/>
<mask id="mask0_5576_19772" style="mask-type:luminance" maskUnits="userSpaceOnUse" x="1" y="1" width="22" height="23">
<path id="Mask_2" fill-rule="evenodd" clip-rule="evenodd" d="M23 17C23 17.6 22.6 18 22 18H2C1.4 18 1 17.6 1 17C1 16.4 1.4 16 2 16C3.1 16 4 15.1 4 14V9C4 4.6 7.6 1 12 1C16.4 1 20 4.6 20 9V14C20 15.1 20.9 16 22 16C22.6 16 23 16.4 23 17ZM14.6 21.5003C14 22.5003 13 23.0003 12 23.0003C11.5 23.0003 11 22.9003 10.5 22.6003C10 22.3003 9.7 22.0003 9.4 21.5003C9.1 21.0003 9.3 20.4003 9.8 20.1003C10.3 19.8003 10.9 20.0003 11.2 20.5003C11.2303 20.5306 11.2606 20.5701 11.2936 20.6131C11.3697 20.7123 11.4606 20.8306 11.6 20.9003C12.1 21.2003 12.7 21.0003 13 20.5003C13.3 20.0003 13.9 19.9003 14.4 20.1003C14.9 20.3003 14.9 21.0003 14.6 21.5003ZM18 14C18 14.7 18.2 15.4 18.5 16H5.5C5.8 15.4 6 14.7 6 14V9C6 5.7 8.7 3 12 3C15.3 3 18 5.7 18 9V14Z" fill="white"/>
</mask>
<g mask="url(#mask0_5576_19772)">
<g id="Icon Color">
<rect id="&#240;&#159;&#142;&#168; Icon Color" width="24" height="24" fill="#dc616a"/>
</g>
</g>
</g>
</svg>    
    `;
  } else if (data_List_chats[i].new == "soon") {
    h3_New.innerHTML = `
    <p>400</p>
<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
<g id="34) icon/bell">
<path id="Mask" fill-rule="evenodd" clip-rule="evenodd" d="M23 17C23 17.6 22.6 18 22 18H2C1.4 18 1 17.6 1 17C1 16.4 1.4 16 2 16C3.1 16 4 15.1 4 14V9C4 4.6 7.6 1 12 1C16.4 1 20 4.6 20 9V14C20 15.1 20.9 16 22 16C22.6 16 23 16.4 23 17ZM14.6 21.5003C14 22.5003 13 23.0003 12 23.0003C11.5 23.0003 11 22.9003 10.5 22.6003C10 22.3003 9.7 22.0003 9.4 21.5003C9.1 21.0003 9.3 20.4003 9.8 20.1003C10.3 19.8003 10.9 20.0003 11.2 20.5003C11.2303 20.5306 11.2606 20.5701 11.2936 20.6131C11.3697 20.7123 11.4606 20.8306 11.6 20.9003C12.1 21.2003 12.7 21.0003 13 20.5003C13.3 20.0003 13.9 19.9003 14.4 20.1003C14.9 20.3003 14.9 21.0003 14.6 21.5003ZM18 14C18 14.7 18.2 15.4 18.5 16H5.5C5.8 15.4 6 14.7 6 14V9C6 5.7 8.7 3 12 3C15.3 3 18 5.7 18 9V14Z" fill="#14142B"/>
<mask id="mask0_5576_19772" style="mask-type:luminance" maskUnits="userSpaceOnUse" x="1" y="1" width="22" height="23">
<path id="Mask_2" fill-rule="evenodd" clip-rule="evenodd" d="M23 17C23 17.6 22.6 18 22 18H2C1.4 18 1 17.6 1 17C1 16.4 1.4 16 2 16C3.1 16 4 15.1 4 14V9C4 4.6 7.6 1 12 1C16.4 1 20 4.6 20 9V14C20 15.1 20.9 16 22 16C22.6 16 23 16.4 23 17ZM14.6 21.5003C14 22.5003 13 23.0003 12 23.0003C11.5 23.0003 11 22.9003 10.5 22.6003C10 22.3003 9.7 22.0003 9.4 21.5003C9.1 21.0003 9.3 20.4003 9.8 20.1003C10.3 19.8003 10.9 20.0003 11.2 20.5003C11.2303 20.5306 11.2606 20.5701 11.2936 20.6131C11.3697 20.7123 11.4606 20.8306 11.6 20.9003C12.1 21.2003 12.7 21.0003 13 20.5003C13.3 20.0003 13.9 19.9003 14.4 20.1003C14.9 20.3003 14.9 21.0003 14.6 21.5003ZM18 14C18 14.7 18.2 15.4 18.5 16H5.5C5.8 15.4 6 14.7 6 14V9C6 5.7 8.7 3 12 3C15.3 3 18 5.7 18 9V14Z" fill="white"/>
</mask>
<g mask="url(#mask0_5576_19772)">
<g id="Icon Color">
<rect id="&#240;&#159;&#142;&#168; Icon Color" width="24" height="24" fill="#dc616a"/>
</g>
</g>
</g>
</svg>
    `;
  } else if (data_List_chats[i].new == false) {
    h3_New.innerHTML = "";
  }
  divcontaineradds.appendChild(h3_New);
  let pcontaineradds = document.createElement('p');
  pcontaineradds.textContent = data_List_chats[i].p;
  divcontaineradds.appendChild(pcontaineradds);
}
  }
})